# Reolink Mail Notifications

Because google FCM has removed the push notification api we use
we now must resort to email notifications for PIR messages

This is a test crate to investigate this
