pub(crate) mod codex;
/// Deserlizer for BCMedia
pub mod de;
/// Structure model for BCMedia
pub mod model;
/// Serlizer for BCMedia
pub mod ser;
