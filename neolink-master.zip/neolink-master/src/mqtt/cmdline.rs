use clap::Parser;

#[derive(Parser, Debug)]
pub struct Opt {}
