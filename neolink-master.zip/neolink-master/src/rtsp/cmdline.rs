use clap::Parser;

/// The rtsp command will serve all cameras in the config over the rtsp protocol
#[derive(Parser, Debug)]
pub struct Opt {}
