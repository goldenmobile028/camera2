#docker --name=l2tp-ipsec-radius-docker build -t l2tp-ipsec-radius-docker .
docker exec -it rtsp-samsung-tv bash
