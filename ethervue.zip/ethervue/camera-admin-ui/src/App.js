import React from 'react'; // eslint-disable-line no-unused-vars
import Config from './components/Config'; // eslint-disable-line no-unused-vars
import './App.css';

function App() {
  return (
        <div className="App">
            <header className="App-header">
                <Config/>
            </header>

        </div>
  );
}

export default App;
